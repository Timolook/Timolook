package com.lvxinkang.controller;

import com.github.pagehelper.PageInfo;
import com.lvxinkang.bean.Bills;
import com.lvxinkang.bean.Billtype;
import com.lvxinkang.service.BillTypesService;
import com.lvxinkang.service.BillsService;
import com.lvxinkang.util.PageUtil;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


@Controller
public class BillsController {
    @Resource
    private BillTypesService typesService;
    @Resource
    private BillsService billsService;

    /**
     * 值查询账单类型
     * @return
     */
    @RequestMapping("/getBillType")
    public String getBillType(ModelMap map){

        List<Billtype> types = typesService.getTypes();
        map.addAttribute("types", types);

        return "add";
    }


    @RequestMapping("/gettypes")
    public String gettypes(ModelMap map){
        // 1 查询所有账单类型
        List<Billtype> types = typesService.getTypes();

        // 2 查询所有的账单
        PageInfo<Bills> info = billsService.getBills(-1, null, null, 1, PageUtil.PAGESIZE);

        // 保存数据给前台
        map.addAttribute("types", types);
        map.addAttribute("info", info);

        return "show";
    }

    /**
     * 查询所有账单
     * @return
     */
    @RequestMapping("/getAllBills")
    public String getBills(@RequestParam(defaultValue = "1") int index, @RequestParam(defaultValue = "-1") Integer typeId, String begin, String end, ModelMap map){

        PageInfo<Bills> info = billsService.getBills(typeId, begin, end, index, PageUtil.PAGESIZE);
        map.addAttribute("info", info);
        // 数据回显
        // 将模糊查询的条件值再返回给前台
        map.addAttribute("tid", typeId);
        map.addAttribute("begintime", begin);
        map.addAttribute("endtime", end);

        List<Billtype> types = typesService.getTypes();
        map.addAttribute("types", types);

        return "show";
    }

    /**
     * 记账
     * @return
     */
    @RequestMapping("/insertBill")
    public String add(Bills bills){
        int insert = billsService.insert(bills);
        if (insert > 0){
            // 回到主页面
            return "redirect:/gettypes";
        }
        // 回到新增页面
        return "redirect:/getBillType";
    }

    /**
     * 通过id查找账单
     * @param bid
     * @param map
     * @return
     */
    @RequestMapping("/findById")
    public String findById(int bid, ModelMap map){
        Bills bills = billsService.selectByPrimaryKey(bid);
        List<Billtype> types = typesService.getTypes();
        map.addAttribute("bills", bills);
        map.addAttribute("types", types);
        return "update";
    }

    /**
     * 更新账单
     * @param bills
     * @return
     */
    @RequestMapping("/updateBill")
    public String updateBill(Bills bills){
        int i = billsService.updateByPrimaryKey(bills);
        if (i > 0){
            return "redirect:/gettypes";
        }
        return "redirect:/findById?bid=" + bills.getId();
    }


    @RequestMapping("/deleteById")
    public void delete(int bid, HttpServletResponse response){
        int i = billsService.deleteByPrimaryKey(bid);
        response.setContentType("text/html;charset=utf-8");
        try {
            PrintWriter writer  = response.getWriter();
            if (i > 0){
                writer.print("<script>alert('删除成功');location.href='/gettypes'</script>");
                return;
            }
            writer.print("<script>alert('删除失败');location.href='/gettypes'</script>");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
