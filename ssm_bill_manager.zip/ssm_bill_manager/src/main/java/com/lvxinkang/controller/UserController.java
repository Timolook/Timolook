package com.lvxinkang.controller;

import javax.annotation.Resource;
import javax.swing.*;

import com.lvxinkang.bean.Bills;
import com.lvxinkang.bean.Billtype;
import com.lvxinkang.service.BillTypesService;
import com.lvxinkang.service.BillsService;
import com.lvxinkang.util.PageUtil;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.lvxinkang.bean.User;
import com.lvxinkang.service.UserService;

import java.util.List;

@Controller
@RequestMapping("/user")

//这里用了@SessionAttributes，可以直接把model中的user(也就key)放入其中
//这样保证了session中存在user这个对象
@SessionAttributes("user")
public class UserController {

    @Autowired
    private UserService userServivce;
    @Resource
    private BillTypesService typesService;
    @Resource
    private BillsService billsService;
    //正常访问login页面
    @RequestMapping("/login")
    public String login(){
        return "login";
    }

    //表单提交过来的路径
    @RequestMapping("/checkLogin1")
    public String checkLogin(User user, Model model, @RequestParam(defaultValue = "1") int index, @RequestParam(defaultValue = "-1") Integer typeId, String begin, String end, ModelMap map){
        //调用service方法
        user = userServivce.checkLogin(user.getUsername(), user.getPassword());
        //若有user则添加到model里并且跳转到成功页面

         if(user != null){
            model.addAttribute("user",user);
            PageInfo<Bills> info = billsService.getBills(typeId, begin, end, index, PageUtil.PAGESIZE);
            map.addAttribute("info", info);
            // 数据回显
            // 将模糊查询的条件值再返回给前台
            map.addAttribute("tid", typeId);
            map.addAttribute("begintime", begin);
            map.addAttribute("endtime", end);

            List<Billtype> types = typesService.getTypes();
            map.addAttribute("types", types);
            return "show1";

        }
        else{
        JOptionPane.showMessageDialog(null, "账号或者密码错误，请重新输入！");
        return "login";}
    }



    @RequestMapping("/doRegist")
    public String doRegist(User user,Model model){
        System.out.println(user.getUsername());
        userServivce.Regist(user);
        JOptionPane.showMessageDialog(null, "注册成功");
        return "login";
    }
}