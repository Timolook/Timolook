package com.lvxinkang.util;

public interface PageUtil {

    public int PAGESIZE = 5;
}
