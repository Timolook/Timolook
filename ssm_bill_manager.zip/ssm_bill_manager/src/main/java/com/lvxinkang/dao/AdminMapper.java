package com.lvxinkang.dao;

import com.lvxinkang.bean.Admin;
import org.apache.ibatis.annotations.Param;

public interface AdminMapper {


    /**
     * 查找用户名和密码
     * @param adminname 登录用户名
     * @return
     */
    Admin findByAdminname(String adminname);
    /**
     * 注册用户和密码
     */
    void registerByAdminnameAndPassword(@Param("adminname") String adminname,
                                       @Param("password") String password);
}