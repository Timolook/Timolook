package com.lvxinkang.dao;

import com.lvxinkang.bean.Billtype;

import java.util.List;

public interface BilltypeMapper {

    public List<Billtype> getTypes();

    int deleteByPrimaryKey(Integer id);

    int insert(Billtype record);

    int insertSelective(Billtype record);

    Billtype selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Billtype record);

    int updateByPrimaryKey(Billtype record);
}