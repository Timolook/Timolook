package com.lvxinkang.service.impl;


import com.lvxinkang.bean.Admin;
import com.lvxinkang.dao.AdminMapper;
import com.lvxinkang.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminMapper adminDao;

    /*
     * 检验用户登录业务
     *
     */

    public Admin checkLogin(String adminname, String password) {

        Admin admin = adminDao.findByAdminname(adminname);
        if(admin != null && admin.getPassword().equals(password)){

            return admin;
        }
        return null;
    }

    @Override
    public void Regist(Admin admin) {

        adminDao.registerByAdminnameAndPassword(admin.getAdminname(),admin.getPassword());

    }
}