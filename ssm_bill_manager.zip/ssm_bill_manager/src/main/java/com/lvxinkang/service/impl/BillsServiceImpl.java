package com.lvxinkang.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lvxinkang.bean.Bills;
import com.lvxinkang.dao.BillsMapper;
import com.lvxinkang.service.BillsService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class BillsServiceImpl implements BillsService {

    @Resource
    private BillsMapper billsMapper;

    @Override
    public Bills selectByPrimaryKey(Integer id) {
        return billsMapper.selectByPrimaryKey(id);
    }

    /**
     * 查询所有账单
     *
     * @return
     */
    @Override
    public PageInfo<Bills> getBills(int typeId, String begin, String end, int index, int size) {
        Map params = new HashMap();
        params.put("tid", typeId);
        params.put("begin", begin);
        params.put("end", end);

        // 1 指定分页数据
        PageHelper.startPage(index, size);
        // 2 查询数据
        List<Bills> bills = billsMapper.getBills(params);
        // 3 创建分页工具类
        PageInfo<Bills> info = new PageInfo<>(bills);

        return info;
    }

    @Override
    @Transactional
    public int insert(Bills record) {
        return billsMapper.insert(record);
    }

    @Override
    @Transactional
    public int updateByPrimaryKey(Bills record) {
        return billsMapper.updateByPrimaryKey(record);
    }

    @Override
    @Transactional
    public int deleteByPrimaryKey(Integer id) {
        return billsMapper.deleteByPrimaryKey(id);
    }
}
