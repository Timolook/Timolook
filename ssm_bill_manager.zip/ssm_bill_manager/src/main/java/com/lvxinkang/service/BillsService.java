package com.lvxinkang.service;

import com.github.pagehelper.PageInfo;
import com.lvxinkang.bean.Bills;


public interface BillsService {

    Bills selectByPrimaryKey(Integer id);

    /**
     * 查询所有账单
     * @return
     */
    public PageInfo<Bills> getBills(int typeId, String begin, String end, int index, int size);

    public int insert(Bills record);

    public int updateByPrimaryKey(Bills record);

    public int deleteByPrimaryKey(Integer id);

}
