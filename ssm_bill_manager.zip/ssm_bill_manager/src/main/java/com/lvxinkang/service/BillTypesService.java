package com.lvxinkang.service;

import com.lvxinkang.bean.Billtype;

import java.util.List;


public interface BillTypesService {

    /**
     * 查询所有账单类型
     * @return
     */
    public List<Billtype> getTypes();
}
