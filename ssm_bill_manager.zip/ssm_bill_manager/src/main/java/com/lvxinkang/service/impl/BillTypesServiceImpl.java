package com.lvxinkang.service.impl;

import com.lvxinkang.bean.Billtype;
import com.lvxinkang.dao.BilltypeMapper;
import com.lvxinkang.service.BillTypesService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;


@Service
public class BillTypesServiceImpl implements BillTypesService {
    @Resource
    private BilltypeMapper billtypeMapper;

    /**
     * 查询所有账单类型
     *
     * @return
     */
    @Override
    public List<Billtype> getTypes() {
        return billtypeMapper.getTypes();
    }
}
