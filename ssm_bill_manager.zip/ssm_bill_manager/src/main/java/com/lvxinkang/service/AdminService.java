package com.lvxinkang.service;


import com.lvxinkang.bean.Admin;

//Service层接口
public interface AdminService {

    //检验用户登录
    Admin checkLogin(String adminname, String password);
    void Regist(Admin admin);
}