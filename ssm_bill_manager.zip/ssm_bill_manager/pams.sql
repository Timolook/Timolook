/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50556
 Source Host           : localhost:3306
 Source Schema         : pams

 Target Server Type    : MySQL
 Target Server Version : 50556
 File Encoding         : 65001

 Date: 11/06/2021 22:45:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminname` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES (1, 'admin', 'admin');

-- ----------------------------
-- Table structure for bills
-- ----------------------------
DROP TABLE IF EXISTS `bills`;
CREATE TABLE `bills`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `billtime` date NULL DEFAULT NULL,
  `typeId` int(11) NULL DEFAULT NULL,
  `price` double NULL DEFAULT NULL,
  `explains` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 45 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of bills
-- ----------------------------
INSERT INTO `bills` VALUES (38, '123', '2020-01-20', 12, 2, 'asdasd');
INSERT INTO `bills` VALUES (39, '123', '2020-01-21', 13, 2, '12312');
INSERT INTO `bills` VALUES (40, '123', '2020-01-20', 15, 2, 'q');
INSERT INTO `bills` VALUES (41, '123', '2020-01-20', 13, 2, '123123');
INSERT INTO `bills` VALUES (42, '123', '2020-01-20', 15, 2, 'ddd');
INSERT INTO `bills` VALUES (43, 'asdasd', '2020-01-20', 15, 3, 'ddd');
INSERT INTO `bills` VALUES (44, 'asdasd', '2020-01-20', 17, 2, 'dd');

-- ----------------------------
-- Table structure for billtype
-- ----------------------------
DROP TABLE IF EXISTS `billtype`;
CREATE TABLE `billtype`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bname` varchar(5) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of billtype
-- ----------------------------
INSERT INTO `billtype` VALUES (12, '支出');
INSERT INTO `billtype` VALUES (13, '借出');
INSERT INTO `billtype` VALUES (14, '还钱');
INSERT INTO `billtype` VALUES (15, '收入');
INSERT INTO `billtype` VALUES (16, '借入');
INSERT INTO `billtype` VALUES (17, '还入');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`username`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('zhangsan', '12345678');

SET FOREIGN_KEY_CHECKS = 1;
